echo "Stopping..."
killall screen
echo "Stopped"
