# - *- coding: utf- 8 - *-
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup
from tgbot.services.sqlite import get_settings, get_payments, get_all_categories, get_positions, get_items, \
get_pod_category, get_pod_categories, get_position
from design import products, profile, faq, support, refill, faq_chat_inl, faq_news_inl, support_inl, ref_system, promocode, \
last_purchases_text, back, close_text, refill_link_inl, refill_check_inl, bitcoin_text, adminmenu, subscribe, check_sub, buybutton, yesiwantbutton, noidontwantbutton, checkbtcpay, checkcardpay, card_text, jobs, rules, instbtc
from tgbot.data import config
from tgbot.utils.utils_functions import get_admins, send_admins

def sub():
    s = InlineKeyboardMarkup()
    s.row(InlineKeyboardButton(text=subscribe, url=config.channel_url))
    s.row(InlineKeyboardButton(text=check_sub, callback_data='subprov'))

    return s

def user_menu(user_id):
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)

    status_buy = get_settings()['is_buy']

    if (status_buy == "True"):
        keyboard.row(products, profile)
    else:
        keyboard.row(profile)
    keyboard.row(faq, support)
    keyboard.row(jobs, rules)
    #keyboard.row(instbtc)


    if user_id in get_admins():
        keyboard.row(adminmenu)

    return keyboard


def faq_inl():
    keyboard = InlineKeyboardMarkup()
    kb = []
    news = get_settings()['news']
    chat = get_settings()['chat']

    kb.append(InlineKeyboardButton(faq_chat_inl, url=chat))
    kb.append(InlineKeyboardButton(faq_news_inl, url=news))

    keyboard.add(kb[0])
    keyboard.add(kb[1])

    return keyboard

def support_inll():
    keyboard = InlineKeyboardMarkup()
    kb = []
    kb.append(InlineKeyboardButton(support_inl, url=get_settings()['support']))

    keyboard.add(kb[0])

    return keyboard

def chat_inl():
    keyboard = InlineKeyboardMarkup()
    kb = []
    link = get_settings()['chat']

    kb.append(InlineKeyboardButton(faq_chat_inl, url=link))

    keyboard.add(kb[0])

    return keyboard

def news_inl():
    keyboard = InlineKeyboardMarkup()
    kb = []
    link = get_settings()['news']

    kb.append(InlineKeyboardButton(faq_news_inl, url=link))

    keyboard.add(kb[0])

    return keyboard

def profile_inl():
    keyboard = InlineKeyboardMarkup()
    kb = []
    status_ref = get_settings()['is_ref']
    status_refill = get_settings()['is_refill']


    if (status_ref == "True"):
        kb.append(InlineKeyboardButton(ref_system, callback_data="ref_system"))
    kb.append(InlineKeyboardButton(promocode, callback_data="promo_act"))
    kb.append(InlineKeyboardButton(last_purchases_text, callback_data="last_purchases"))
    if (status_refill == "True"):
        kb.append(InlineKeyboardButton(refill, callback_data="refill"))
    ##kb.append(InlineKeyboardButton(back, callback_data="back_to_user_menu"))

    if (len(kb) == 4):
        keyboard.add(kb[3])
        keyboard.add(kb[0])
        keyboard.add(kb[1])
        keyboard.add(kb[2])
    elif (len(kb) == 3):
        keyboard.add(kb[2])
        keyboard.add(kb[0])
        keyboard.add(kb[1])
    elif (len(kb) == 2):
        keyboard.add(kb[0])
        keyboard.add(kb[1])
   ## keyboard.add(kb[3])

    return keyboard

def back_to_profile():
    keyboard = InlineKeyboardMarkup()

    keyboard.add(InlineKeyboardButton(back, callback_data="profilebck"))

    return keyboard

def back_to_user_menu():
    keyboard = InlineKeyboardMarkup()

    keyboard.add(InlineKeyboardButton(back, callback_data="back_to_user_menu"))

    return keyboard


def close_inl():
    keyboard = InlineKeyboardMarkup()
    kb = []

    kb.append(InlineKeyboardButton(close_text, callback_data="close_text_mail"))

    keyboard.add(kb[0])

    return keyboard

def refill_open_inl(way, amount, link, id):
    keyboard = InlineKeyboardMarkup()
    kb = []

    kb.append(InlineKeyboardButton(refill_link_inl, url=link))
    kb.append(InlineKeyboardButton(refill_check_inl, callback_data=f"check_opl:{way}:{amount}:{id}"))

    keyboard.add(kb[0])
    keyboard.add(kb[1])

    return keyboard

def refill_inl():
    keyboard = InlineKeyboardMarkup()
    kb = []
    bitcoin = get_payments()['pay_bitcoin']
    card = get_payments()['pay_card']

    if bitcoin == "True":
        kb.append(InlineKeyboardButton(bitcoin_text, callback_data="refill:bitcoin"))
    if card == "True":
        kb.append(InlineKeyboardButton(card_text, callback_data="refill:card"))

    if len(kb) == 1:
        keyboard.add(kb[0])
    if len(kb) == 2:
        keyboard.add(kb[0])
        keyboard.add(kb[1])

    keyboard.add(InlineKeyboardButton(back, callback_data="profilebck"))

    return keyboard

def back_to_user_menu():
    keyboard = InlineKeyboardMarkup()
    kb = []

    keyboard.add(InlineKeyboardButton(back, callback_data="back_to_user_menu"))

    return keyboard

def open_products():
    keyboard = InlineKeyboardMarkup()

    for category in get_all_categories():
        name = category['name']
        cat_id = category['id']
        keyboard.add(InlineKeyboardButton(name, callback_data=f"open_category:{cat_id}"))

    ##keyboard.add(InlineKeyboardButton(back, callback_data="back_to_user_menu"))

    return keyboard

def open_pod_cat_positions(pod_cat_id):
    keyboard = InlineKeyboardMarkup()

    for pos in get_positions(pod_cat_id=pod_cat_id):
        name = pos['name']
        pos_id = pos['id']
        price = pos['price']
        items = f"{len(get_items(position_id=pos_id))}шт"
        if pos['infinity'] == "+":
            items = "[Безлимит]"
        keyboard.add(InlineKeyboardButton(f"{name} | {price}₽ | {items}", callback_data=f"open_pos:{pos_id}"))

    keyboard.add(InlineKeyboardButton(back, callback_data=f"open_category:{get_pod_category(pod_cat_id)['cat_id']}"))

    return keyboard
def open_positions(cat_id):
    keyboard = InlineKeyboardMarkup()

    for pod_cat in get_pod_categories(cat_id):
        name = pod_cat['name']
        pod_cat_id = pod_cat['id']
        keyboard.add(InlineKeyboardButton(name, callback_data=f"open_pod_cat:{pod_cat_id}"))
    for pos in get_positions(cat_id):
        if pos['pod_category_id'] is not None:
            continue
        name = pos['name']
        pos_id = pos['id']
        price = pos['price']
        items = f"{len(get_items(position_id=pos_id))}шт"
        if pos['infinity'] == "+":
            items = "[Безлимит]"
        keyboard.add(InlineKeyboardButton(f"{name} | {price}₽ | {items}", callback_data=f"open_pos:{pos_id}"))

    keyboard.add(InlineKeyboardButton(back, callback_data=f"products:open"))

    return keyboard

def pos_buy_inl(pos_id):
    keyboard = InlineKeyboardMarkup()

    keyboard.add(InlineKeyboardButton(buybutton, callback_data=f"buy_pos:{pos_id}"))
    keyboard.add(InlineKeyboardButton(back, callback_data=f"open_category:{get_position(pos_id)['category_id']}"))

    return keyboard

def choose_buy_items(pos_id, amount):
    keyboard = InlineKeyboardMarkup()
    kb = []

    kb.append(InlineKeyboardButton(yesiwantbutton, callback_data=f"buy_items:yes:{pos_id}:{amount}"))
    kb.append(InlineKeyboardButton(noidontwantbutton, callback_data=f"buy_items:no:{pos_id}:{amount}"))

    keyboard.add(kb[0], kb[1])

    return keyboard

def refill_bill_btc():
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(checkbtcpay, callback_data=f"Pay:bitcoin:")
    )

    return keyboard

def refill_bill_card():
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton(checkcardpay, callback_data=f"Pay:card:")
    )

    return keyboard