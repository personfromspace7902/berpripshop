# - *- coding: utf- 8 - *-
import decimal

from aiogram.dispatcher import FSMContext
from aiogram.types import Message, CallbackQuery
from tgbot.services.api_btc import BtcApi
from tgbot.services.sqlite import add_btc_paymentx, get_cards_count, get_current_card, get_settings
from design import refill_text, refill_amount_text, min_amount, max_amount, \
min_max_amount, no_int_amount, carddisable, generate_refill, btc_wait_refill, card_wait_refill,card_wait_refill_op
from tgbot.keyboards.inline_user import refill_inl,  refill_bill_btc, refill_bill_card, support_inll
from tgbot.data.loader import dp
import random
from tgbot.utils.utils_functions import send_admins



@dp.callback_query_handler(text="refill", state="*")
async def refill_open(call: CallbackQuery, state: FSMContext):
    await state.finish()

    await call.message.delete()
    await call.message.answer(refill_text, reply_markup=refill_inl())

@dp.callback_query_handler(text_startswith="refill:", state="*")
async def refill_(call: CallbackQuery, state: FSMContext):
    await state.finish()

    way = call.data.split(":")[1]
    if (way == "card"):
        num = int(get_cards_count())
        if (num == 0):
            await call.message.answer(f"<b>{carddisable}</b>")
        else:
            await state.update_data(here_way=way)
            await state.set_state("here_amount_refill")
            await call.message.answer(refill_amount_text)
    else:
        await state.update_data(here_way=way)
        await state.set_state("here_amount_refill")
        await call.message.answer(refill_amount_text)



@dp.message_handler(state="here_amount_refill")
async def refill_pay(message: Message, state: FSMContext):
    amount = message.text
    way = (await state.get_data())['here_way']

    if amount.isdigit():
        pay_amount = int(amount)
        if min_amount <= pay_amount <= max_amount:
            if way == "bitcoin":
                await message.answer(generate_refill)
                sat, addr = BtcApi().create_order(pay_amount)
                print(f"Создается запрос на оплату BTC на сумму {pay_amount} руб. для пользователя {message.from_user}")
                await message.answer(f"<b>Переведите <code>{round(sat * decimal.Decimal(0.00000001), 10)}</code> BTC"
                                              f" на адрес <code>{addr}</code></b>\n\n<em>Адрес будет продублирован отдельным сообщением (для удобного копирования с телефона):</em>")
                await message.answer(f"<code>{addr}</code>", reply_markup=refill_bill_btc())
                add_btc_paymentx(addr, sat, message.from_user.id, pay_amount)
            await state.finish()

            if way == "card":
                await message.answer(generate_refill)
                cards_count = int(get_cards_count())
                card_id = random.randint(1, cards_count)
                adress = get_current_card(card_id)
                summ = pay_amount + random.randint(1, 55)
                await message.answer(f"<b>Переведите <code>{summ}</code> руб. на карту <code>{adress}</code></b>", reply_markup=refill_bill_card())

                await send_admins(f"<b>Пользователь @{message.from_user.username} создал заявку на пополнение картой \n\nID пользователя: <code>{message.from_user.id}</code>\nСумма пополнения: <code>{summ}</code> руб.\nНомер карты: <code>{adress}</code></b>", True)


        else:
            await message.answer(min_max_amount)
    else:
        await message.answer(no_int_amount)

@dp.callback_query_handler(text_startswith="Pay:bitcoin:")
async def refill_check_btc(call: CallbackQuery):
    await call.message.edit_text(btc_wait_refill)

@dp.callback_query_handler(text_startswith="Pay:card:")
async def refill_check_btc(call: CallbackQuery, state: FSMContext):
    get_support = get_settings()['support']
    if get_support == "None" or get_support == "-":
        await call.message.edit_text(card_wait_refill)
    else:
        await call.message.edit_text(
            card_wait_refill_op,
            reply_markup=support_inll())


