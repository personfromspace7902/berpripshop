# - *- coding: utf- 8 - *-
import asyncio

from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery, Message
from tgbot.services.sqlite import get_payments, update_payments
from design import  bitcoin_text, uprtov, search, spam, stat, allset, extset, onoffers, paysyst, home
from tgbot.utils.utils_functions import ots, get_admins
from tgbot.keyboards.inline_admin import payments_settings_info, payments_settings, payments_back
from tgbot.filters.is_admin import IsAdmin
from tgbot.data.loader import dp
from tgbot.data import config

@dp.message_handler(text=paysyst, state="*")
async def payments_settings_choose(message: Message, state: FSMContext):
    if (message.from_user.id in get_admins()):
        await state.finish()

        await message.answer("<b>⚙️ Выберите способ оплаты</b>", reply_markup=payments_settings())


@dp.callback_query_handler(IsAdmin(), text_startswith="paymentsbck", state="*")
async def payments_back(call: CallbackQuery, state: FSMContext):
    await state.finish()

    await call.message.delete()
    await call.message.answer("<b>⚙️ Выберите способ оплаты</b>", reply_markup=payments_settings())

@dp.callback_query_handler(IsAdmin(), text_startswith="payments:", state="*")
async def payments_info(call: CallbackQuery, state: FSMContext):
    await state.finish()
    way = call.data.split(":")[1]

    def pay_info(way, status):
        if status == "True":
            status = "✅ Включен"
        elif status == "False":
            status = "❌ Выключен"

        msg = f"""
<b>{way}

Статус: <code>{status}</code></b>        
"""
        return ots(msg)

    if way == "bitcoin":
        ways = bitcoin_text
        status = get_payments()['pay_bitcoin']

        await call.message.edit_text(pay_info(ways, status), reply_markup=payments_settings_info(way, status))
    elif way == "card":
        ways = "Картой"
        status = get_payments()['pay_card']

        await call.message.edit_text(pay_info(ways, status), reply_markup=payments_settings_info(way, status))

@dp.callback_query_handler(IsAdmin(), text_startswith="payments_on_off:", state="*")
async def off_payments(call: CallbackQuery, state: FSMContext):

    way = call.data.split(":")[1]
    action = call.data.split(":")[2]

    def pay_info(way, status):
        if status == "True":
            status = "✅ Включен"
        elif status == "False":
            status = "❌ Выключен"

        msg = f"""
    <b>{way}

    Статус: <code>{status}</code></b>        
    """
        return ots(msg)

    if way == "bitcoin":
        ways = bitcoin_text

        if action == "off":
            update_payments(pay_bitcoin="False")
        else:
            update_payments(pay_bitcoin="True")

        status = get_payments()['pay_bitcoin']

        await call.message.edit_text(pay_info(ways, status), reply_markup=payments_settings_info(way, status))

    if way == "card":
        ways = "Картой"

        if action == "off":
            update_payments(pay_card="False")
        else:
            update_payments(pay_card="True")

        status = get_payments()['pay_card']

        await call.message.edit_text(pay_info(ways, status), reply_markup=payments_settings_info(way, status))
