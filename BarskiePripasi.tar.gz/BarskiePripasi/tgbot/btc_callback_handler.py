import configparser
from subprocess import call

from fastapi import FastAPI, HTTPException
from fastapi import status as stst
from tgbot.services.sqlite import get_btc_paymentx, get_user, add_refill, update_user, remove_btc_paymentx
from tgbot.utils.utils_functions import get_date, get_unix
from tgbot.data.config import blockonomics_secret, bot_token
from aiogram.types import CallbackQuery
from tgbot.utils.utils_functions import send_admins
from design import refill_success_text, yes_refill_ref
from tgbot.services.sqlite import get_settings
from tgbot.data.loader import bot

from aiogram import Bot
import asyncio

app = FastAPI()

# cfg = configparser.ConfigParser()
# cfg.read("settings.ini")
KEY = blockonomics_secret
BOT_TOKEN = bot_token


async def send_message_to_user(user_id: int, message_text: str):
    bot = Bot(token=BOT_TOKEN)
    await bot.send_message(chat_id=user_id, text=message_text)


# Example usage:

# h<gA.s9dz%}WEm2p
@app.get("/callback/")
def handle_callback(status: int, addr: str, value: int, txid: str, secret_key: str):
    if secret_key != KEY:
        raise HTTPException(status_code=stst.HTTP_401_UNAUTHORIZED)
    print(f"Transaction from {addr} with {value / 100_000_000}BTC and {txid=}\n secret_key auth success")
    if status == 0:
        r = get_btc_paymentx(addr, value)
        if r:
            asyncio.run(send_message_to_user(r['user_id'],
                                             f"<b>Ваш платёж на адрес</b><code> {addr} </code><b>суммой</b><code> {r['amount_rubs']}</code> <b>руб. найден и ожидает подтверждения</b>"))
    elif status == 1:
        r = get_btc_paymentx(addr, value)
        if r:
            asyncio.run(send_message_to_user(r['user_id'],
                                             f"<b>Ваш платёж на адрес</b><code> {addr}</code><b> суммой<b><code> {r['amount_rubs']}</code> <b>руб. подтвержден на 50%</b>"))
    elif status == 2:
        r = get_btc_paymentx(addr, value)
        if r:
            ##get_user = get_userx(user_id=r['user_id'])

            amount = r['amount_rubs']
            usid = r['user_id']
            id = get_unix() + usid
            way = 'bitcoin'
            user = get_user(id=usid)

            msg = f"💰 Произошло пополнение баланса! \n" \
                  f"👤 Пользователь: <b>@{user['user_name']}</b> | <a href='tg://user?id={user['id']}'>{user['first_name']}</a> | <code>{user['id']}</code>\n" \
                  f"💵 Сумма пополнения: <code>{amount} RUB</code>\n" \
                  f"🧾 Чек: <code>{id}</code> \n" \
                  f"⚙️ Способ: <code>{way}</code>"
            send_admins(msg, True)

            add_refill(amount, way, usid, user['user_name'], user['first_name'], comment=id)
            update_user(id=usid, balance=int(user['balance']) + int(amount),
                        total_refill=int(user['total_refill']) + int(amount),
                        count_refills=int(user['count_refills']) + 1)
            remove_btc_paymentx(addr, value)
            asyncio.run(send_message_to_user(r['user_id'], refill_success_text(way, amount, id)))
            if get_settings()['is_ref'] == "False":
                pass
            elif get_settings()['is_ref'] == "True":
                if user['ref_id'] is None:
                    pass
                else:
                    reffer = get_user(id=user['ref_id'])

                    if reffer['ref_lvl'] == 1:
                        ref_percent = get_settings()['ref_percent_1']
                    elif reffer['ref_lvl'] == 2:
                        ref_percent = get_settings()['ref_percent_2']
                    elif reffer['ref_lvl'] == 3:
                        ref_percent = get_settings()['ref_percent_3']

                    ref_amount = int(amount) / 100 * int(ref_percent)
                    reffer_id = user['ref_id']
                    reffer_balance = get_user(id=reffer_id)['balance']
                    ref_earn = reffer_balance = get_user(id=reffer_id)['ref_earn']
                    add_balance = round(reffer_balance + round(ref_amount, 1), 2)
                    name = f"<a href='tg://user?id={user['id']}'>{user['user_name']}</a>"
                    update_user(reffer_id, balance=add_balance, ref_earn=ref_earn + round(ref_amount, 1))
                    await bot.send_message(reffer_id, yes_refill_ref.format(name=name, amount=amount,
                                                                            ref_amount=round(ref_amount, 1)))
            asyncio.run(send_message_to_user(r['user_id'], f"<b>Ваш баланс был пополнен на</b> <em>{r['amount_rubs']}</em>\n<b>Приятных покупок! ❤️</b>"))
    return ""