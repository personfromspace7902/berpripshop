# - *- coding: utf- 8 - *-
import configparser

read_config = configparser.ConfigParser()
read_config.read("settings.ini")

# TELEGRAM BOT
bot_token = read_config['settings']['token'].strip().replace(" ", "")  # Токен бота
path_database = "tgbot/data/database.db"  # Путь к Базе Данных
bot_version = "2.3"  # Версия бота

# Каналы
channel_id = read_config['settings']['channel_id'].strip().replace(" ", "") # айди канала для подписки
channel_url = read_config['settings']['channel_url'].strip().replace(" ", "") # ссылка на канал
logs_channel_id = read_config['settings']['logs_channel_id'].strip().replace(" ", "") # айди канала для логов


blockonomics_api = read_config['settings']['blockonomics_api'].strip().replace(" ", "")
blockonomics_secret = read_config['settings']['blockonomics_secret'].strip().replace(" ", "")