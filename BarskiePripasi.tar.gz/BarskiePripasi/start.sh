
echo "starting bot service"
screen -dmS bot python3 main.py
echo "starting callback service"
screen -dmS callback uvicorn tgbot.btc_callback_handler:app --port 7902 --host 0.0.0.0
